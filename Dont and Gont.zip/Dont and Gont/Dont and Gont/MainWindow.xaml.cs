﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace TaskPlanner
{
    public partial class MainWindow : Window
    {
        public ObservableCollection<Task> Tasks { get; set; } = new ObservableCollection<Task>();
        public ObservableCollection<Category> Categories { get; set; } = new ObservableCollection<Category>();

        private Task selectedTask; 
        public MainWindow()
        {
            InitializeComponent();
            DataContext = this;

                        Categories.Add(new Category { Name = "Работа" });
            Categories.Add(new Category { Name = "Учёба" });
            Categories.Add(new Category { Name = "Домашние дела" });

                        Tasks.Add(new Task { Name = "Завершить проект", Description = "Доделать презентацию", Category = Categories[0], StartDate = DateTime.Now, EndDate = DateTime.Now.AddDays(3), Priority = Priority.High });
            Tasks.Add(new Task { Name = "Сдать курсовую работу", Description = "Написать курсовую по истории", Category = Categories[1], StartDate = DateTime.Now.AddDays(1), EndDate = DateTime.Now.AddDays(14), Priority = Priority.Medium });
            Tasks.Add(new Task { Name = "Помыть посуду", Description = "Все грязные тарелки", Category = Categories[2], StartDate = DateTime.Now, Priority = Priority.Low });

                        TaskListView.SelectionChanged += TaskListView_SelectionChanged;
        }

        private void TaskListView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (e.AddedItems.Count > 0)
            {
                selectedTask = (Task)e.AddedItems[0];             }
            else
            {
                selectedTask = null;             }
        }

        private void AddTask_Click(object sender, RoutedEventArgs e)
        {
                        string newName = Microsoft.VisualBasic.Interaction.InputBox("Введите название задачи:", "Добавить задачу");
            string newDescription = Microsoft.VisualBasic.Interaction.InputBox("Введите описание задачи:", "Добавить задачу");

                        string categoryName = "";
            foreach (Category category in Categories)
            {
                categoryName += category.Name + "\n";
            }
            string selectedCategory = Microsoft.VisualBasic.Interaction.InputBox("Выберите категорию:\n" + categoryName, "Добавить задачу");
            Category chosenCategory = Categories.FirstOrDefault(c => c.Name == selectedCategory);

                        string selectedPriority = Microsoft.VisualBasic.Interaction.InputBox("Выберите приоритет:\nНизкий\nСредний\nВысокий", "Добавить задачу");
            Priority priority = Priority.Low;
            switch (selectedPriority)
            {
                case "Средний":
                    priority = Priority.Medium;
                    break;
                case "Высокий":
                    priority = Priority.High;
                    break;
            }

                        Tasks.Add(new Task
            {
                Name = newName,
                Description = newDescription,
                Category = chosenCategory,
                StartDate = DateTime.Now,
                EndDate = DateTime.Now.AddDays(7),
                Priority = priority
            });
        }

        private void EditTask_Click(object sender, RoutedEventArgs e)
        {
            if (selectedTask != null)
            {
                                string newName = Microsoft.VisualBasic.Interaction.InputBox("Введите новое название задачи:", "Редактировать задачу", selectedTask.Name);
                string newDescription = Microsoft.VisualBasic.Interaction.InputBox("Введите новое описание задачи:", "Редактировать задачу", selectedTask.Description);

                                string categoryName = "";
                foreach (Category category in Categories)
                {
                    categoryName += category.Name + "\n";
                }
                string selectedCategory = Microsoft.VisualBasic.Interaction.InputBox("Выберите категорию:\n" + categoryName, "Редактировать задачу", selectedTask.Category.Name);
                Category chosenCategory = Categories.FirstOrDefault(c => c.Name == selectedCategory);

                                string selectedPriority = Microsoft.VisualBasic.Interaction.InputBox("Выберите приоритет:\nНизкий\nСредний\nВысокий", "Редактировать задачу", selectedTask.Priority.ToString());
                Priority priority = Priority.Low;
                switch (selectedPriority)
                {
                    case "Средний":
                        priority = Priority.Medium;
                        break;
                    case "Высокий":
                        priority = Priority.High;
                        break;
                }

                                selectedTask.Name = newName;
                selectedTask.Description = newDescription;
                selectedTask.Category = chosenCategory;
                selectedTask.Priority = priority;
            }
            else
            {
                MessageBox.Show("Выберите задачу для редактирования.");
            }
        }

        private void DeleteTask_Click(object sender, RoutedEventArgs e)
        {
            if (selectedTask != null)
            {
                Tasks.Remove(selectedTask);
            }
            else
            {
                MessageBox.Show("Выберите задачу для удаления.");
            }
        }
    }

    public class Task : INotifyPropertyChanged
    {
        private string _name;
        public string Name
        {
            get { return _name; }
            set { _name = value; OnPropertyChanged(nameof(Name)); }
        }

        private string _description;
        public string Description
        {
            get { return _description; }
            set { _description = value; OnPropertyChanged(nameof(Description)); }
        }

        private Category _category;
        public Category Category
        {
            get { return _category; }
            set { _category = value; OnPropertyChanged(nameof(Category)); }
        }

        private DateTime _startDate;
        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; OnPropertyChanged(nameof(StartDate)); }
        }

        private DateTime _endDate;
        public DateTime EndDate
        {
            get { return _endDate; }
            set { _endDate = value; OnPropertyChanged(nameof(EndDate)); }
        }

        private Priority _priority;
        public Priority Priority
        {
            get { return _priority; }
            set { _priority = value; OnPropertyChanged(nameof(Priority)); }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class Category
    {
        public string Name { get; set; }
    }

    public enum Priority
    {
        Low,
        Medium,
        High
    }
}