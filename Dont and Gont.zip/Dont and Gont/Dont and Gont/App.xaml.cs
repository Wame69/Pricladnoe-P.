﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Dont_and_Gont
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
