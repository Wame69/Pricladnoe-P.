﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace Сomprehensive_visual_script_editor
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
