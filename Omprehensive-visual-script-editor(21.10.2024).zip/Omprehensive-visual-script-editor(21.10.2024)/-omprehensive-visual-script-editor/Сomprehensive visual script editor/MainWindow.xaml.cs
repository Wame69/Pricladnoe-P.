﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Shapes;
using System.Windows.Media;
using System.Collections.Generic;

namespace ScriptEditor
{
    public partial class MainWindow : Window
    {
        private bool _isDragging;
        private Point _dragStartPoint;
        private Grid _selectedBlock;
        private bool _isConnecting;
        private List<Line> _lines;
        private Dictionary<string, object> _variables;

        public MainWindow()
        {
            InitializeComponent();
            _lines = new List<Line>();
            _variables = new Dictionary<string, object>();
        }

        private void AddBlock_Click(object sender, RoutedEventArgs e)
        {
            string blockType = (string)((Button)sender).CommandParameter;
            AddBlock(blockType);
        }

        private void AddBlock(string blockName)
        {
            var blockContainer = new Grid
            {
                Width = 100,
                Height = 50,
                Tag = blockName
            };

            var block = new Rectangle
            {
                Width = 100,
                Height = 50,
                Fill = Brushes.LightBlue,
                Stroke = Brushes.Black,
                StrokeThickness = 2
            };

            var textBlock = new TextBlock
            {
                Text = blockName,
                VerticalAlignment = VerticalAlignment.Center,
                HorizontalAlignment = HorizontalAlignment.Center
            };

            blockContainer.Children.Add(block);
            blockContainer.Children.Add(textBlock);

            double blockY = 50 * (ScriptCanvas.Children.Count / 2 + 1);
            Canvas.SetLeft(blockContainer, 50);
            Canvas.SetTop(blockContainer, blockY);
            ScriptCanvas.Children.Add(blockContainer);

            blockContainer.MouseMove += Block_MouseMove;
            blockContainer.MouseUp += Block_MouseUp;
            blockContainer.MouseDown += Block_MouseDown;

            if (blockName == "Условие")
            {
                CreateConditionBlock(blockContainer, textBlock);
            }
            else if (blockName == "Ввод переменной")
            {
                CreateInputVariableBlock(blockContainer);
            }
            else if (blockName == "Цикл")
            {
                CreateLoopBlock(blockContainer, textBlock);
            }
        }

        private void CreateConditionBlock(Grid blockContainer, TextBlock textBlock)
        {
            var conditionComboBox = new ComboBox
            {
                Width = 80,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(5)
            };

            conditionComboBox.Items.Add("Выберите...");
            conditionComboBox.Items.Add("if");
            conditionComboBox.Items.Add("else");

            conditionComboBox.SelectedIndex = 0;

            conditionComboBox.SelectionChanged += (sender, e) =>
            {
                if (conditionComboBox.SelectedItem != null && conditionComboBox.SelectedItem.ToString() != "Выберите...")
                {
                    var selectedCondition = conditionComboBox.SelectedItem.ToString();
                    textBlock.Text = selectedCondition;

                    conditionComboBox.Visibility = Visibility.Collapsed;
                }
            };

            Canvas.SetLeft(conditionComboBox, Canvas.GetLeft(blockContainer) + 10);
            Canvas.SetTop(conditionComboBox, Canvas.GetTop(blockContainer) + 60);
            ScriptCanvas.Children.Add(conditionComboBox);

            blockContainer.Tag = conditionComboBox;
        }

        private void CreateInputVariableBlock(Grid blockContainer)
        {
            var inputTextBox = new TextBox
            {
                Width = 80,
                Margin = new Thickness(5),
                VerticalAlignment = VerticalAlignment.Bottom
            };

            inputTextBox.KeyDown += (sender, e) =>
            {
                if (e.Key == Key.Enter)
                {
                    string inputText = inputTextBox.Text;
                    if (!string.IsNullOrWhiteSpace(inputText))
                    {
                        var splitInput = inputText.Split('=');
                        if (splitInput.Length == 2)
                        {
                            string variableName = splitInput[0].Trim();
                            string variableValue = splitInput[1].Trim();

                            if (int.TryParse(variableValue, out int intValue))
                            {
                                _variables[variableName] = intValue;
                            }
                            else
                            {
                                _variables[variableName] = variableValue;
                            }

                            var textBlock = blockContainer.Children[1] as TextBlock;
                            textBlock.Text = $"{variableName} = {variableValue}";

                            inputTextBox.Visibility = Visibility.Collapsed;
                        }
                        else
                        {
                            MessageBox.Show("Введите данные в формате: переменная = значение");
                        }
                    }
                }
            };

            Canvas.SetLeft(inputTextBox, Canvas.GetLeft(blockContainer) + 10);
            Canvas.SetTop(inputTextBox, Canvas.GetTop(blockContainer) + 60);
            ScriptCanvas.Children.Add(inputTextBox);

            blockContainer.Tag = inputTextBox;
        }

        private void CreateLoopBlock(Grid blockContainer, TextBlock textBlock)
        {
            var loopComboBox = new ComboBox
            {
                Width = 80,
                VerticalAlignment = VerticalAlignment.Bottom,
                Margin = new Thickness(5)
            };

            loopComboBox.Items.Add("Выберите...");
            loopComboBox.Items.Add("for");
            loopComboBox.Items.Add("while");

            loopComboBox.SelectedIndex = 0;

            loopComboBox.SelectionChanged += (sender, e) =>
            {
                if (loopComboBox.SelectedItem != null && loopComboBox.SelectedItem.ToString() != "Выберите...")
                {
                    var selectedLoop = loopComboBox.SelectedItem.ToString();
                    textBlock.Text = selectedLoop;

                    loopComboBox.Visibility = Visibility.Collapsed;
                }
            };

            Canvas.SetLeft(loopComboBox, Canvas.GetLeft(blockContainer) + 10);
            Canvas.SetTop(loopComboBox, Canvas.GetTop(blockContainer) + 60);
            ScriptCanvas.Children.Add(loopComboBox);

            blockContainer.Tag = loopComboBox;
        }

        private void Block_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (sender is Grid blockContainer)
            {
                if (_isConnecting)
                {
                    if (_selectedBlock == null)
                    {
                        _selectedBlock = blockContainer;
                    }
                    else
                    {
                        DrawLine(_selectedBlock, blockContainer);
                        _selectedBlock = null;
                        _isConnecting = false;
                    }
                }
                else
                {
                    _selectedBlock = blockContainer;
                }
            }
        }

        private void DrawLine(Grid fromBlock, Grid toBlock)
        {
            var line = new Line
            {
                Stroke = Brushes.Black,
                StrokeThickness = 2
            };

            double fromX = Canvas.GetLeft(fromBlock) + fromBlock.Width / 2;
            double fromY = Canvas.GetTop(fromBlock) + fromBlock.Height;
            double toX = Canvas.GetLeft(toBlock) + toBlock.Width / 2;
            double toY = Canvas.GetTop(toBlock);

            line.X1 = fromX;
            line.Y1 = fromY;
            line.X2 = toX;
            line.Y2 = toY;

            ScriptCanvas.Children.Add(line);
            _lines.Add(line);
        }

        private void Block_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed && sender is Grid blockContainer)
            {
                if (!_isDragging)
                {
                    _isDragging = true;
                    _dragStartPoint = e.GetPosition(ScriptCanvas);
                    Mouse.Capture(blockContainer);
                }

                var currentPoint = e.GetPosition(ScriptCanvas);
                double offsetX = currentPoint.X - _dragStartPoint.X;
                double offsetY = currentPoint.Y - _dragStartPoint.Y;

                double newLeft = Canvas.GetLeft(blockContainer) + offsetX;
                double newTop = Canvas.GetTop(blockContainer) + offsetY;

                Canvas.SetLeft(blockContainer, newLeft);
                Canvas.SetTop(blockContainer, newTop);

                _dragStartPoint = currentPoint;
            }
        }

        private void Block_MouseUp(object sender, MouseButtonEventArgs e)
        {
            if (_isDragging)
            {
                _isDragging = false;
                Mouse.Capture(null);
            }
        }

        private void AddConnection_Click(object sender, RoutedEventArgs e)
        {
            _isConnecting = true;
            _selectedBlock = null;
        }

        private void RemoveSelectedBlock_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedBlock != null)
            {
                foreach (var line in _lines)
                {
                    if (line.X1 == Canvas.GetLeft(_selectedBlock) + _selectedBlock.Width / 2 &&
                        line.Y1 == Canvas.GetTop(_selectedBlock) + _selectedBlock.Height ||
                        line.X2 == Canvas.GetLeft(_selectedBlock) + _selectedBlock.Width / 2 &&
                        line.Y2 == Canvas.GetTop(_selectedBlock))
                    {
                        ScriptCanvas.Children.Remove(line);
                    }
                }

                ScriptCanvas.Children.Remove(_selectedBlock);
                _selectedBlock = null;
            }
        }

        private void ExecuteScript_Click(object sender, RoutedEventArgs e)
        {
            ExecuteScript(sender, e);
        }

        private async void ExecuteScript(object sender, RoutedEventArgs e)
        {
            foreach (var child in ScriptCanvas.Children)
            {
                if (child is Grid blockContainer)
                {
                    if (blockContainer.Tag is ComboBox comboBox && comboBox.Visibility == Visibility.Visible)
                    {
                        var selectedItem = comboBox.SelectedItem.ToString();

                        if (selectedItem == "if" && _variables.ContainsKey("a") && (int)_variables["a"] > 10)
                        {
                            MessageBox.Show("Выполняем блок if");
                        }
                        else if (selectedItem == "else")
                        {
                            MessageBox.Show("Выполняем блок else");
                        }

                        if (selectedItem == "for")
                        {
                            for (int i = 0; i < 5; i++)
                            {
                                MessageBox.Show($"Выполняем блок for: {i}");
                            }
                        }
                        else if (selectedItem == "while")
                        {
                            int counter = 0;
                            while (counter < 5)
                            {
                                MessageBox.Show($"Выполняем блок while: {counter}");
                                counter++;
                            }
                        }
                    }
                }
            }
        }
    }
}
