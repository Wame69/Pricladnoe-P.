﻿using System.Windows.Forms.DataVisualization.Charting;
namespace ExpenseTracker
{
    partial class Form1
    {
        /// <summary>
        /// Требуемая переменная для конструктора компонента.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Очистка всех используемых ресурсов.
        /// </summary>
        /// <param name="disposing">Истинно, если управляемые ресурсы должны быть освобождены; иначе Ложь.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код генератора компонентов Windows Form Designer

        private void InitializeComponent()
        {
            ChartArea chartArea1 = new ChartArea();
            Series series1 = new Series();
            cbCategory = new ComboBox();
            dtpDate = new DateTimePicker();
            tbAmount = new TextBox();
            btnAddExpense = new Button();
            lvExpenses = new ListView();
            columnDate = new ColumnHeader();
            columnCategory = new ColumnHeader();
            columnAmount = new ColumnHeader();
            btnDeleteExpense = new Button();
            btnExportToFile = new Button();
            expenseChart = new Chart();
            cbCategoryFilter = new ComboBox();
            btnSortByDate = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)expenseChart).BeginInit();
            SuspendLayout();
            // 
            // cbCategory
            // 
            cbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCategory.FormattingEnabled = true;
            cbCategory.Location = new Point(150, 12);
            cbCategory.Name = "cbCategory";
            cbCategory.Size = new Size(121, 23);
            cbCategory.TabIndex = 0;
            // 
            // dtpDate
            // 
            dtpDate.Location = new Point(12, 12);
            dtpDate.Name = "dtpDate";
            dtpDate.Size = new Size(132, 23);
            dtpDate.TabIndex = 1;
            // 
            // tbAmount
            // 
            tbAmount.Location = new Point(277, 12);
            tbAmount.Name = "tbAmount";
            tbAmount.Size = new Size(100, 23);
            tbAmount.TabIndex = 2;
            // 
            // btnAddExpense
            // 
            btnAddExpense.Location = new Point(383, 10);
            btnAddExpense.Name = "btnAddExpense";
            btnAddExpense.Size = new Size(109, 23);
            btnAddExpense.TabIndex = 3;
            btnAddExpense.Text = "Добавить расход";
            btnAddExpense.UseVisualStyleBackColor = true;
            btnAddExpense.Click += btnAddExpense_Click;
            // 
            // lvExpenses
            // 
            lvExpenses.Columns.AddRange(new ColumnHeader[] { columnDate, columnCategory, columnAmount });
            lvExpenses.FullRowSelect = true;
            lvExpenses.GridLines = true;
            lvExpenses.Location = new Point(12, 50);
            lvExpenses.Name = "lvExpenses";
            lvExpenses.Size = new Size(360, 200);
            lvExpenses.TabIndex = 4;
            lvExpenses.UseCompatibleStateImageBehavior = false;
            lvExpenses.View = View.Details;
            // 
            // columnDate
            // 
            columnDate.Text = "Дата";
            columnDate.Width = 100;
            // 
            // columnCategory
            // 
            columnCategory.Text = "Категория";
            columnCategory.Width = 120;
            // 
            // columnAmount
            // 
            columnAmount.Text = "Сумма";
            columnAmount.Width = 80;
            // 
            // btnDeleteExpense
            // 
            btnDeleteExpense.Location = new Point(383, 50);
            btnDeleteExpense.Name = "btnDeleteExpense";
            btnDeleteExpense.Size = new Size(109, 23);
            btnDeleteExpense.TabIndex = 5;
            btnDeleteExpense.Text = "Удалить расход";
            btnDeleteExpense.UseVisualStyleBackColor = true;
            btnDeleteExpense.Click += btnDeleteExpense_Click;
            // 
            // btnExportToFile
            // 
            btnExportToFile.Location = new Point(383, 79);
            btnExportToFile.Name = "btnExportToFile";
            btnExportToFile.Size = new Size(109, 23);
            btnExportToFile.TabIndex = 6;
            btnExportToFile.Text = "Экспорт в файл";
            btnExportToFile.UseVisualStyleBackColor = true;
            btnExportToFile.Click += btnExportToFile_Click;
            // 
            // expenseChart
            // 
            chartArea1.Name = "Expenses";
            expenseChart.ChartAreas.Add(chartArea1);
            expenseChart.Location = new Point(12, 260);
            expenseChart.Name = "expenseChart";
            series1.ChartArea = "Expenses";
            series1.Name = "Expenses";
            expenseChart.Series.Add(series1);
            expenseChart.Size = new Size(480, 200);
            expenseChart.TabIndex = 7;
            expenseChart.Text = "chart1";
            // 
            // cbCategoryFilter
            // 
            cbCategoryFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cbCategoryFilter.FormattingEnabled = true;
            cbCategoryFilter.Location = new Point(378, 138);
            cbCategoryFilter.Name = "cbCategoryFilter";
            cbCategoryFilter.Size = new Size(150, 23);
            cbCategoryFilter.TabIndex = 8;
            cbCategoryFilter.SelectedIndexChanged += cbCategoryFilter_SelectedIndexChanged;
            // 
            // btnSortByDate
            // 
            btnSortByDate.Location = new Point(541, 133);
            btnSortByDate.Name = "btnSortByDate";
            btnSortByDate.Size = new Size(157, 30);
            btnSortByDate.TabIndex = 10;
            btnSortByDate.Text = "Сортировать по дате";
            btnSortByDate.UseVisualStyleBackColor = true;
            btnSortByDate.Click += btnSortByDate_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(378, 120);
            label1.Name = "label1";
            label1.Size = new Size(157, 15);
            label1.TabIndex = 11;
            label1.Text = "Сортировка по категориям";
            // 
            // Form1
            // 
            ClientSize = new Size(706, 481);
            Controls.Add(label1);
            Controls.Add(btnSortByDate);
            Controls.Add(cbCategoryFilter);
            Controls.Add(expenseChart);
            Controls.Add(btnExportToFile);
            Controls.Add(btnDeleteExpense);
            Controls.Add(lvExpenses);
            Controls.Add(btnAddExpense);
            Controls.Add(tbAmount);
            Controls.Add(dtpDate);
            Controls.Add(cbCategory);
            Name = "Form1";
            Text = "Трекер расходов";
            ((System.ComponentModel.ISupportInitialize)expenseChart).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private System.Windows.Forms.ComboBox cbCategory;
        private System.Windows.Forms.DateTimePicker dtpDate;
        private System.Windows.Forms.TextBox tbAmount;
        private System.Windows.Forms.Button btnAddExpense;
        private System.Windows.Forms.ListView lvExpenses;
        private System.Windows.Forms.ColumnHeader columnDate;
        private System.Windows.Forms.ColumnHeader columnCategory;
        private System.Windows.Forms.ColumnHeader columnAmount;
        private System.Windows.Forms.Button btnDeleteExpense;
        private System.Windows.Forms.Button btnExportToFile;
        private System.Windows.Forms.DataVisualization.Charting.Chart expenseChart;
        private System.Windows.Forms.ComboBox cbCategoryFilter;
        private System.Windows.Forms.Button btnSortByDate;
        private Label label1;
    }
}
