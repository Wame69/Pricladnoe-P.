using System;
using System.Linq;
using System.Windows.Forms;
using System.Collections.Generic;
using System.Windows.Forms.DataVisualization.Charting;

namespace ExpenseTracker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            InitializeCategoryComboBox();
            InitializeCategoryFilterComboBox();
        }

        private void InitializeCategoryComboBox()
        {
            cbCategory.Items.AddRange(new object[] {
                "���", "���������", "�����������", "������", "��������", "�����������",
                "�����������", "�����", "�������� �������", "�������"
            });
        }

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            if (decimal.TryParse(tbAmount.Text, out decimal amount) && cbCategory.SelectedItem != null)
            {
                var date = dtpDate.Value;
                var category = cbCategory.SelectedItem.ToString();
                var item = new ListViewItem(new[] { date.ToShortDateString(), category, amount.ToString() });

                lvExpenses.Items.Add(item);

                SortListView();

                UpdateChart();
            }
            else
            {
                MessageBox.Show("����������, ������� ���������� ������.");
            }
        }

        private void btnDeleteExpense_Click(object sender, EventArgs e)
        {
            if (lvExpenses.SelectedItems.Count > 0)
            {
                lvExpenses.Items.Remove(lvExpenses.SelectedItems[0]);
                UpdateChart();
            }
            else
            {
                MessageBox.Show("�������� ������ ��� ��������.");
            }
        }

        private void btnExportToFile_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "CSV ���� (*.csv)|*.csv|��� ����� (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                var filePath = saveFileDialog.FileName;
                ExportExpensesToFile(filePath);
            }
        }

        private void ExportExpensesToFile(string filePath)
        {
            using (var writer = new System.IO.StreamWriter(filePath))
            {
                writer.WriteLine("����,���������,�����");

                foreach (ListViewItem item in lvExpenses.Items)
                {
                    var date = item.SubItems[0].Text;
                    var category = item.SubItems[1].Text;
                    var amount = item.SubItems[2].Text;
                    writer.WriteLine($"{date},{category},{amount}");
                }
            }

            MessageBox.Show("������ ������� ��������������.");
        }

        private void SortListView()
        {
            var sortedItems = lvExpenses.Items.Cast<ListViewItem>()
                .OrderByDescending(item => DateTime.Parse(item.SubItems[0].Text))
                .ToList();

            lvExpenses.Items.Clear();

            foreach (var item in sortedItems)
            {
                lvExpenses.Items.Add(item);
            }
        }

        private void UpdateChart()
        {
            expenseChart.Series.Clear();
            expenseChart.ChartAreas.Clear();

            ChartArea chartArea = new ChartArea("Expenses");
            expenseChart.ChartAreas.Add(chartArea);

            Series series = new Series("Expenses")
            {
                ChartType = SeriesChartType.Pie
            };

            var groupedExpenses = lvExpenses.Items.Cast<ListViewItem>()
                .GroupBy(item => item.SubItems[1].Text)
                .Select(g => new { Category = g.Key, Total = g.Sum(i => decimal.Parse(i.SubItems[2].Text)) })
                .ToList();

            foreach (var expense in groupedExpenses)
            {
                series.Points.AddXY(expense.Category, expense.Total);
            }

            expenseChart.Series.Add(series);
        }

        private void btnSortByDate_Click(object sender, EventArgs e)
        {
            SortListView();
            UpdateChart();
        }

        private void btnFilterCategory_Click(object sender, EventArgs e)
        {
            if (cbCategoryFilter.SelectedItem != null)
            {
                string selectedCategory = cbCategoryFilter.SelectedItem.ToString();

                var filteredItems = lvExpenses.Items.Cast<ListViewItem>()
                    .Where(item => item.SubItems[1].Text == selectedCategory)
                    .ToList();

                lvExpenses.Items.Clear();
                foreach (var item in filteredItems)
                {
                    lvExpenses.Items.Add(item);
                }

                UpdateChart(selectedCategory);
            }
            else
            {
                MessageBox.Show("����������, �������� ��������� ��� ����������.");
            }
        }

        private void UpdateChart(string selectedCategory)
        {
            expenseChart.Series.Clear();
            expenseChart.ChartAreas.Clear();

            ChartArea chartArea = new ChartArea("Expenses");
            expenseChart.ChartAreas.Add(chartArea);

            Series series = new Series("Expenses")
            {
                ChartType = SeriesChartType.Pie
            };

            var groupedExpenses = lvExpenses.Items.Cast<ListViewItem>()
                .Where(item => item.SubItems[1].Text == selectedCategory)
                .GroupBy(item => item.SubItems[1].Text)
                .Select(g => new { Category = g.Key, Total = g.Sum(i => decimal.Parse(i.SubItems[2].Text)) })
                .ToList();

            foreach (var expense in groupedExpenses)
            {
                series.Points.AddXY(expense.Category, expense.Total);
            }

            expenseChart.Series.Add(series);
        }

        private void InitializeCategoryFilterComboBox()
        {
            cbCategoryFilter.Items.AddRange(new object[] {
                "��� ���������", "���", "���������", "�����������", "������", "��������",
                "�����������", "�����������", "�����", "�������� �������", "�������"
            });
            cbCategoryFilter.SelectedItem = "��� ���������";
        }

        private void cbCategoryFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            var selectedCategory = cbCategoryFilter.SelectedItem.ToString();

            if (selectedCategory == "��� ���������")
            {
                SortListView();
            }
            else
            {
                var filteredItems = lvExpenses.Items.Cast<ListViewItem>()
                    .Where(item => item.SubItems[1].Text == selectedCategory)
                    .ToList();

                lvExpenses.Items.Clear();
                foreach (var item in filteredItems)
                {
                    lvExpenses.Items.Add(item);
                }
            }

            UpdateChart();
        }
    }
}
